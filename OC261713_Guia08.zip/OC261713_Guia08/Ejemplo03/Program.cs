﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Title = "Conversión de monedas usando Funciones";
            Console.WriteLine("Guia #8 , Ejemplo 3");
            Console.WriteLine();
            Console.Clear();

            //----- Declarar Variables -----//
            Double x, p, r;
            Console.Write("Digitar la cantida en dólares: $ ");
            Console.ForegroundColor = ConsoleColor.Red;
            x = Double.Parse(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine();

            //----- Llamadas a Funciones -----//
            p = euros(x);
            Console.Write("Los " + x +  " dolares son " + p + " euros ");
            Console.WriteLine();

            r = libras(x);
            Console.WriteLine("Los " + x + " dolares son " + r + " libras ");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("--> Fin del Programa ");
            Console.WriteLine();
            Console.ReadKey();


        }

        //----- Funciones -----//
        static Double euros(Double a)
        {
            Double g;
            g = a * 1.15;
            return g;
        }

        static Double libras(Double a)
        {
            Double v;
            v = a * 3.15;
            return v;
        }
    }
}
