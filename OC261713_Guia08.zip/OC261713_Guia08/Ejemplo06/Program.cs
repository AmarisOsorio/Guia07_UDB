﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Title = "Calculadora Cientifica";
            Console.WriteLine("Guia #8 , Ejemplo 06");
            Console.WriteLine();
            Console.Clear();

            //----- Declarar Variables -----//
            int opcion;
            int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0;
            int op2;

            do
            {

            }
            while (true);
        }

        //----- Funciones -----//
        static void suma()
        {
            try
            {
                Double a, b, resultado;
                Console.Write("Digite el primer valor .....:");
                a = Double.Parse(Console.ReadLine());
                Console.WriteLine();
                Console.Write("Digite el segundo valor .....:");
                b = Double.Parse(Console.ReadLine());
                resultado = a + b;
                Console.WriteLine("El resultado es................: " + resultado);
            }
            catch (Exception error)
            {
                Console.WriteLine();
                Console.WriteLine(error.Message);
            }
        }


        static void Resta()
        {
            try
            {
                Double c, d, resultado;
                Console.Write("Digite el primer valor .....: ");
                c = Double.Parse(Console.ReadLine());
                Console.WriteLine();
                Console.Write("Digite el segundo valor .....: ");
                d = Double.Parse(Console.ReadLine()); 
                resultado = c - d;
                Console.WriteLine("El resultado es...........: " + resultado);
            }
            catch (Exception error)
            {
                Console.WriteLine();
                Console.WriteLine(error.Message);
            }
        }


        static void Multiplicación()
        {
            try
            {
                Double e, f, resultado;
                Console.Write("Digite el primer valor .....: ");
            }
        }
    }
}
