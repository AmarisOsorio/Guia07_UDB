﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Title = "Menú matemático con ayuda de los procedimientos";
            Console.WriteLine("Guia #8 , Ejemplo 4");
            Console.WriteLine();
            Console.Clear();

            //----- Declarar Variables -----//
            int num1, num2;
            int opcion;

            Console.WriteLine("MENU PRINCIPAL DE OPERACIONES MATEMATICAS: ");
            Console.WriteLine();
            Console.Write("Digitar el primer número: ");
            num1 = int.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Digitar el segundo número: ");
            num2 = int.Parse(Console.ReadLine());
            Console.Clear();

            Console.ForegroundColor= ConsoleColor.Yellow;
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine();
            Console.WriteLine("1) Mayor de los 2");
            Console.WriteLine("2) Multiplo");
            Console.WriteLine("3) Potencia");
            Console.WriteLine();
            Console.WriteLine("-----------------------------------------");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine();
            Console.Write("Digitar la opción deseada [1..3] ");
            opcion = int.Parse(Console.ReadLine());
            Console.WriteLine();

            switch (opcion)
            {
                case 1:
                    mayor(num1, num2);
                    break;
                case 2:
                    multiplo(num1, num2);
                    break;
                case 3:
                    potencia(num1, num2);
                    break;
                default:
                    Console.WriteLine("Se ha equivocado de opcion, solo acepta[1..3]");
                    break;
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("--> Fin del Programa");
            Console.WriteLine();
            Console.ReadKey();
        }


        //----- Funciones -----//
        static void mayor(int a , int b)
        {
            if(a > b)
            {
                Console.WriteLine("El numero " + a + " es mayor que " + b);
            }
            else
            {
                Console.WriteLine("El numero " + b + " es mayor que " + a);
            }
        }


        static void multiplo(int a , int b)
        {
            int w;
            w = (a % b);
            if (w == 0)
            {
                Console.WriteLine("El numero " + a + " es multiplo de " + b);
            }
            else
            {
                Console.WriteLine("El numero " + b + " no es multiplo de " + a);
            }
        }


        static void potencia(int a, int b)
        {
            Double s;
            s = Math.Pow(a, b);
            Console.WriteLine("El número " + a + " a la potencia de " + b + " es: " + s );
        }
    }
}
